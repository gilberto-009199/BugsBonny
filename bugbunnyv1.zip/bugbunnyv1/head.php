<?php $arquivo=basename($_SERVER['PHP_SELF'],'.php');?>
        <meta charset="utf-8">
        <meta name="generator" content="netbeans">
        <meta name="author" content="Gilberto Oliveira">
        <meta name="copyright" content="Senai-SP">
        <meta name="contactNetworkAddress" content="gilberto.tec@vivaldi.net">
        <meta name="robots" content= "all"><!-- Definindo a aranha ou melhor motores de busca para indexarem todo o site e suas paginas-->
        <script type="text/javascript" src="./libs/jquery/jquery-3.3.1.js"></script>
        <script type="text/javascript" src="./libs/jqueryUI/jquery-ui.min.js"></script>
        <script type="text/javascript" src="./js/lib.js"></script>
        <link rel="icon" type="image/png" href="./img/logo2.png" />
        <link rel="stylesheet" type="text/css" href="<?="./css/".$arquivo.".css"?>">
    
