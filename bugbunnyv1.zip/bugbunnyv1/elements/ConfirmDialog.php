
<div class="ConfirmDialog">
    <div id='titulo' class="titulo"></div>
    <div id='msgDialog' class="msg"></div>
    <div class="Direita">
        <button id='btnConfirm' class="btnConfirm">ok</button>
        <button id='btnRevoke' class="btnRevoke">cancel</button>
    </div>
</div>
