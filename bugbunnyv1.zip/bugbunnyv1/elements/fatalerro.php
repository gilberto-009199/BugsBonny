<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>ERRO</title>
    </head>
    <body style="background-color: red;">
        <p>Por Favor! Avise o administrador pelo e-mail:</p>
        <p><a href="mailto:gilberto.tec@vivaldi.net">gilberto.tec@vivaldi.net</a></p>
        <?php
        // put your code here
        ?>
    </body>
</html>
